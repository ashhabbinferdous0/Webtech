<?php
echo"rejister"

?>