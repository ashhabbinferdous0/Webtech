<?php
require_once('db.php');
function auth($Email,$Pass)
{
	$con=con();
	$sql="select * from student where Email='$Email' and Password='$pass'";
	$res=mysqli_query($con,$sql);
	return $res;
}
function add($Email,$Pass)
{
	$con=con();
	$sql="Insert into student('$Email',$Pass";
	$res=mysqli_query($con,$sql);
	
}

