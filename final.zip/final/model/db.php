<?php 

function con()
{
	$serverName="localhost";
	$userName="root";
	$password="";
	$dbname="student_managent";
	$conn=new mysqli($serverName,$userName,$password,$dbname);
	return $conn;
}

?>