<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student reg</title>
</head>
<body>
    <form action="../Controllers/logcheckController.php" method="post">
        Email:<input type="text"name="Email"><br><br>
        Pass:<input type="password"name="pass"><br><br>
        <button name="login">Login</button>
    </form>
    
</body>
</html>